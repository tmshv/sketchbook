public interface ITree{
    float getPower();
    int getColor();
    String getName();
    void update();
}